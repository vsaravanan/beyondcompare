export class ErrorHelper {
    public static handle(error: Error) {
        console.log(error);
    }
}