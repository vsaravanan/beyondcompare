'use strict';
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const vscode = require("vscode");
const patterns = [
    {
        regex: /^(_*)[A-Z]+(?=_|$)/,
        build(words, groups) {
            return groups[1] + words.map(word => word.toUpperCase()).join('_');
        },
    },
    {
        regex: /[-._/\\: ]/,
        build(words, groups) {
            return words
                .map(word => replace(word, [word]) || word)
                .join(groups[0]);
        },
    },
    {
        regex: /^[a-z][a-z\d]*(?=[A-Z]|$)/,
        build(words) {
            return format(words[0], true) + words.slice(1).map(word => format(word)).join('');
            function format(word, first = false) {
                if (/^[A-Z\d]+$/.test(word)) {
                    return first ? word.toLowerCase() : word;
                }
                else {
                    word = word.toLowerCase();
                    return first ? word : word[0].toUpperCase() + word.slice(1);
                }
            }
        },
    },
    {
        regex: /^[A-Z][a-z\d]*(?=[A-Z]|$)/,
        build(words) {
            return format(words[0]) + words.slice(1).map(word => format(word)).join('');
            function format(word) {
                return word[0].toUpperCase() + word.slice(1);
            }
        },
    },
];
function replace(text, words) {
    for (let pattern of patterns) {
        let groups = pattern.regex.exec(text);
        if (groups) {
            return pattern.build(words, groups);
        }
    }
    return undefined;
}
function split(text) {
    let precededByNumber = false;
    return text
        .split(/[^a-z\d]+/i)
        .filter(part => !!part)
        .reduce((allWords, part) => {
        let words = part
            .replace(/[A-Z]+(?=[A-Z][a-z]|$)|[A-Z]|(\d+)|([a-z])/g, (text, digits, lowerChar, index) => {
            if (index) {
                if (precededByNumber) {
                    precededByNumber = !!digits;
                    return ` ${text}`;
                }
                precededByNumber = !!digits;
                if (lowerChar) {
                    return text;
                }
                else {
                    return ` ${text}`;
                }
            }
            else {
                return text;
            }
        })
            .split(' ');
        return allWords.concat(words);
    }, []);
}
function activate(context) {
    let disposable = vscode.commands.registerTextEditorCommand('sensitive.replace', (editor) => __awaiter(this, void 0, void 0, function* () {
        let selections = editor.selections;
        if (!selections.length) {
            return;
        }
        let document = editor.document;
        let text = yield vscode.window.showInputBox({
            placeHolder: 'Replace (e.g.: "hello world")',
        });
        if (typeof text !== 'string') {
            return;
        }
        let words = split(text);
        yield editor.edit(builder => {
            for (let selection of selections) {
                let replacement = replace(document.getText(selection), words);
                builder.replace(selection, replacement || text);
            }
        });
    }));
    context.subscriptions.push(disposable);
}
exports.activate = activate;
// this method is called when your extension is deactivated
function deactivate() {
}
exports.deactivate = deactivate;
//# sourceMappingURL=extension.js.map