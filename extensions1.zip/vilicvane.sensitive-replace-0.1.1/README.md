# Sensitive Replace (VSCode Extension)

Replace selections while preserving cases.

![Screenshot](https://user-images.githubusercontent.com/970430/27121153-b761edc4-5118-11e7-8412-408c7ff14b95.gif)

## License

MIT License.
