## 0.1.3

- Update header in readme

## 0.1.1

- Removed Git Blame as it duplicated functionality of GitLens

## 0.1.0

- Initial release
