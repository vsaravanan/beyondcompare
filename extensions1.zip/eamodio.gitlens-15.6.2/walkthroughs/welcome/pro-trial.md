<figure align="center">
  <img src="rocket.webp" alt="Power-up with Pro and the GitKraken DevEx Platform"/>
</figure>
