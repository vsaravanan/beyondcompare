## Feature

- View the React Code Coverage report in default browser.
- By running `code coverage` command in command palette it will launch the browser with current React code coverage report.
